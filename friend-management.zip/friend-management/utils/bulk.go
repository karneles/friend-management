package utils

import (
	uuid "github.com/satori/go.uuid"
)

type BulkRequest struct {
	Items []uuid.UUID `json:"items"`
}
